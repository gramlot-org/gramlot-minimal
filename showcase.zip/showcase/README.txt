Gramlot unified showcase — offline development preview

Extract the ENTIRE ZIP, then open index.html in your browser.
Keep index.html, pages/ and assets/ together. Do not open inside the ZIP viewer.
No Python installation or server is required to view local lessons.
The original shell, navigation tree, closable lesson tabs and Source/Inspector
are preserved. The catalog uses relative exported page URLs. Browser resources
are packaged locally. Original Python source is included under source/.

The dataRpc lesson preserves its source, but has no Python backend. It reports
an explicit offline error. A static server does not enable RPC.
This export is a development preview of gramlot-poc, not core port acceptance.

If a browser restricts local iframe files, serve this directory with a static
HTTP server and open its index.html. This uses the same files and no RPC backend.
Verification details are recorded alongside the archive in the repository.
